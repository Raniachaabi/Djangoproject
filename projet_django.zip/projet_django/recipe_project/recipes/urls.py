from django.urls import path
from . import views  # Import views from the current app

urlpatterns = [
    path('', views.recipe_list, name='recipe_list'),  # Main page: list of recipes
    path('recipe/<int:id>/', views.recipe_detail, name='recipe_detail'),  # Recipe detail page
    path('add/', views.add_recipe, name='add_recipe'),  # Form to add a recipe
    path('search/', views.search, name='search_results'),  # Search functionality
    path('favorite/<int:id>/', views.favorite_recipe, name='recipe_favorite'),  # Favorite a recipe
]
 # Or any view you created