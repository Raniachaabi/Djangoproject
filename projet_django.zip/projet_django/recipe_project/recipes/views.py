from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Recipe, Comment, Rating, Favorite
from .forms import RecipeForm, CommentForm
from django.db.models import Q, Avg

# Create your views here.
def recipe_list(request):
    recipes = Recipe.objects.all()  # Fetch all recipes from the database
    return render(request, 'recipe/recipe_list.html', {'recipes': recipes})

def recipe_detail(request, id):
    recipe = get_object_or_404(Recipe, id=id)
    comments = Comment.objects.filter(recipe=recipe)
    avg_rating = Rating.objects.filter(recipe=recipe).aggregate(Avg('score'))['score__avg']
    comment_form = CommentForm()

    return render(request, 'recipe/recipe_detail.html', {
        'recipe': recipe,
        'comments': comments,
        'avg_rating': avg_rating or 0,
        'comment_form': comment_form
    })
@login_required
def add_recipe(request):
    if request.method == 'POST':
        form = RecipeForm(request.POST)
        if form.is_valid():
            recipe = form.save(commit=False)
            recipe.author = request.user
            recipe.save()
            return redirect('recipe_detail', id=recipe.id)
    else:
        form = RecipeForm()
    return render(request, 'recipe/add_recipe.html', {'form': form})
def search(request):
    query = request.GET.get('q')
    results = Recipe.objects.filter(
        Q(title__icontains=query) |
        Q(ingredients__icontains=query) |
        Q(cuisine__icontains=query)
    ).distinct() if query else []
    return render(request, 'recipe/search_results.html', {'recipes': results, 'query': query})
@login_required
def favorite_recipe(request, id):
    recipe = get_object_or_404(Recipe, id=id)
    Favorite.objects.get_or_create(user=request.user, recipe=recipe)
    return redirect('recipe_detail', id=recipe.id)
@login_required
def add_comment(request, id):
    recipe = get_object_or_404(Recipe, id=id)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.user = request.user
            comment.recipe = recipe
            comment.save()
            
            # Optional: Handle rating from form data if included
            rating = request.POST.get('rating')
            if rating:
                Rating.objects.update_or_create(
                    user=request.user,
                    recipe=recipe,
                    defaults={'score': rating}
                )

    return redirect('recipe_detail', id=recipe.id)